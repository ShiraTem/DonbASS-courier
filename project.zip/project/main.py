from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from database import engine, Base
from routers import auth_courier, orders, wallet, reviews

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Courier App Backend",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],  
    allow_headers=["*"],  
)

app.include_router(auth_courier.router)
app.include_router(orders.router)
app.include_router(wallet.router)
app.include_router(reviews.router)

@app.get("/")
def root():
    return {"message": "Бэкенд запущен!"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)