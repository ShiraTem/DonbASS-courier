from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
import bcrypt
from authx import AuthX, AuthXConfig, TokenPayload

from database import get_db
import models
import schemas

router = APIRouter(prefix="/api/couriers/auth", tags=["Courier Auth"])

config = AuthXConfig(
    JWT_SECRET_KEY="SUPER_SECRET_COURIER_KEY_CHANGE_ME",
    JWT_ALGORITHM="HS256",
    JWT_TOKEN_LOCATION=["headers"],
)

auth = AuthX(config=config)

def hash_password(password: str) -> str:
    pwd_bytes = password.encode('utf-8')[:72]
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(pwd_bytes, salt)
    return hashed.decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    pwd_bytes = plain_password.encode('utf-8')[:72]
    return bcrypt.checkpw(pwd_bytes, hashed_password.encode('utf-8'))

@router.post("/register", response_model=schemas.CourierResponse)
def register_courier(data: schemas.CourierRegister, db: Session = Depends(get_db)):
    existing = db.query(models.Courier).filter(models.Courier.username == data.username).first()
    if existing:
        raise HTTPException(status_code=400, detail="Курьер с таким логином уже существует")
    
    hashed_pwd = hash_password(data.password)
    new_courier = models.Courier(
        username=data.username,
        hashed_password=hashed_pwd,
        full_name=data.full_name,
        phone=data.phone
    )
    db.add(new_courier)
    db.commit()
    db.refresh(new_courier)
    return new_courier

@router.post("/login", response_model=schemas.TokenResponse)
def login_courier(data: schemas.CourierLogin, db: Session = Depends(get_db)):
    courier = db.query(models.Courier).filter(models.Courier.username == data.username).first()
    if not courier or not verify_password(data.password, courier.hashed_password):
        raise HTTPException(status_code=400, detail="Неверный логин или пароль")
    
    token = auth.create_access_token(uid=str(courier.id))
    return {"access_token": token, "token_type": "bearer"}

@router.get("/me", response_model=schemas.CourierResponse)
def get_my_profile(
    payload: TokenPayload = Depends(auth.access_token_required), 
    db: Session = Depends(get_db)
):
    courier_id = int(payload.sub)
    courier = db.query(models.Courier).filter(models.Courier.id == courier_id).first()
    if not courier:
        raise HTTPException(status_code=404, detail="Курьер не найден")
    return courier