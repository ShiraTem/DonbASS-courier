from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from database import get_db
import models
import schemas
from routers.auth_courier import auth, TokenPayload

router = APIRouter(prefix="/api/wallet", tags=["Wallet"])

@router.get("/", response_model=schemas.WalletResponse)
def get_my_wallet(payload: TokenPayload = Depends(auth.access_token_required), db: Session = Depends(get_db)):
    courier_id = int(payload.sub)
    transactions = db.query(models.WalletTransaction).filter(
        models.WalletTransaction.courier_id == courier_id
    ).all()
    
    balance = db.query(func.sum(models.WalletTransaction.amount)).filter(
        models.WalletTransaction.courier_id == courier_id
    ).scalar() or 0.0

    return {
        "courier_id": courier_id,
        "balance": balance,
        "transactions": transactions
    }

@router.post("/adjust/{courier_id}")
def adjust_wallet_balance(courier_id: int, data: schemas.WalletTransactionCreate, db: Session = Depends(get_db)):
    courier = db.query(models.Courier).filter(models.Courier.id == courier_id).first()
    if not courier:
        raise HTTPException(status_code=404, detail="Курьер не найден")

    transaction = models.WalletTransaction(
        courier_id=courier_id,
        amount=data.amount,
        type=data.type
    )
    db.add(transaction)
    db.commit()

    new_balance = db.query(func.sum(models.WalletTransaction.amount)).filter(
        models.WalletTransaction.courier_id == courier_id
    ).scalar() or 0.0

    return {"message": "Баланс успешно обновлен", "new_balance": new_balance}