from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from database import get_db
import models
import schemas
from routers.auth_courier import auth, TokenPayload

router = APIRouter(prefix="/api/orders", tags=["Orders"])

@router.post("/", response_model=schemas.OrderResponse)
def create_order(data: schemas.OrderCreate, db: Session = Depends(get_db)):
    order = models.Order(**data.dict(), status="created")
    db.add(order)
    db.commit()
    db.refresh(order)
    return order

@router.get("/available", response_model=List[schemas.OrderResponse])
def get_available_orders(db: Session = Depends(get_db)):
    return db.query(models.Order).filter(models.Order.status == "created").all()

@router.post("/{order_id}/accept", response_model=schemas.OrderResponse)
def accept_order(order_id: int, payload: TokenPayload = Depends(auth.access_token_required), db: Session = Depends(get_db)):
    courier_id = int(payload.sub)
    order = db.query(models.Order).filter(models.Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")
    if order.status != "created":
        raise HTTPException(status_code=400, detail="Заказ уже занят или выполнен")
    
    order.status = "accepted"
    order.courier_id = courier_id
    db.commit()
    db.refresh(order)
    return order

@router.patch("/{order_id}/status", response_model=schemas.OrderResponse)
def update_order_status(order_id: int, status: str, payload: TokenPayload = Depends(auth.access_token_required), db: Session = Depends(get_db)):
    order = db.query(models.Order).filter(models.Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")
    
    order.status = status
    
    if status == "completed" and order.courier_id:
        transaction = models.WalletTransaction(
            courier_id=order.courier_id,
            amount=order.price,
            type="earn"
        )
        db.add(transaction)

    db.commit()
    db.refresh(order)
    return order

@router.delete("/{order_id}")
def delete_order(order_id: int, db: Session = Depends(get_db)):
    order = db.query(models.Order).filter(models.Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")
    db.delete(order)
    db.commit()
    return {"message": "Заказ успешно удален"}