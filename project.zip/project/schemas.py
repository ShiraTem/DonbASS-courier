from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class CourierRegister(BaseModel):
    username: str
    password: str
    full_name: Optional[str] = None
    phone: Optional[str] = None

class CourierLogin(BaseModel):
    username: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class CourierResponse(BaseModel):
    id: int
    username: str
    full_name: Optional[str] = None
    phone: Optional[str] = None

    class Config:
        from_attributes = True

class OrderCreate(BaseModel):
    title: str
    address: str
    price: float

class OrderResponse(OrderCreate):
    id: int
    status: str
    courier_id: Optional[int] = None

    class Config:
        from_attributes = True

class WalletTransactionCreate(BaseModel):
    amount: float
    type: str = "bonus"

class TransactionResponse(BaseModel):
    id: int
    amount: float
    type: str
    timestamp: datetime

    class Config:
        from_attributes = True

class WalletResponse(BaseModel):
    courier_id: int
    balance: float
    transactions: List[TransactionResponse] = []

class ReviewCreate(BaseModel):
    rating: int = Field(..., ge=1, le=5)
    comment: Optional[str] = None
    client_name: str = "Клиент"

class ReviewResponse(ReviewCreate):
    id: int
    courier_id: int
    created_at: datetime

    class Config:
        from_attributes = True